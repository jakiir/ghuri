#### change log - 1.1.6 #####
/inc/frontend/hotel/functions.php
/inc/frontend/tour/functions.php
/functions.php
/style.css

#### change log - 1.1.5 #####
/style.css
/functions.php
/templates/tour/checkout.php
/templates/hotel/checkout.php
/inc/js_composer/js_composer.php
/inc/js_composer/vc_templates/vc_row.php
/inc/functions/template-functions.php
/inc/functions/functions.php
/inc/frontend/tour/functions.php
/inc/frontend/hotel/functions.php
/css/style.css

#### change log - 1.1.4 #####
/inc/frontend/tour/functions.php
/functions.php
/header.php
/single-hotel.php
/single-tour.php
/style.css

#### change log - 1.1.3 #####
/css/responsive.css
/css/style.css
/inc/admin/hotel/orders-admin-panel.php
/inc/admin/hotel/reviews-admin-panel.php
/inc/admin/js/order.js
/inc/admin/tour/orders-admin-panel.php
/inc/frontend/hotel/ajax.php
/inc/frontend/hotel/functions.php
/inc/frontend/tour/ajax.php
/inc/frontend/tour/functions.php
/inc/js_composer/js_composer.php
/inc/lib/payment/main.php
/inc/lib/payment/paypal.php
/inc/lib/redux-framework/config.php
/templates/hotel/checkout.php
/templates/tour/checkout.php
/functions.php
/single-post.php
/style.css

#### change log - 1.1.1 #####
/style.css
/functions.php
/templates/template-home.php
/templates/tour/thankyou.php
/templates/tour/cart.php
/templates/hotel/cart.php
/inc/functions/metaboxes.php
/inc/frontend/tour/functions.php
/inc/frontend/tour/ajax.php
/inc/frontend/hotel/functions.php
/inc/frontend/hotel/ajax.php
/css/style.css

#### change log - 1.1 #####
/inc/frontend/tour/functions.php
/templates/tour/cart.php
/tempates/tour/thankyou.pp
/functions.php

#### change log - 1.0.9 #####
/inc/lib/meta-box/js/custom.js
/inc/functions/metaboxes.php
/single-tour.php
/functions.php

#### change log - 1.0.8 #####
/inc/admin/hotel/vacancies-admin-panel.php
/inc/frontend/hotel/functions.php
/inc/frontend/tour/functions.php
/inc/functions/metaboxes.php
/inc/js_composer/js_composer.php
/inc/lib/meta-box/js/custom.js
/templates/tour/cart.php
/archive-hotel.php
/archive-tour.php
/functions.php
/single-tour.php
/style.css

#### change log - 1.0.6 #####
/header.php
/functions.php
/templates/tour/cart.php
/inc/shortcode/shortcode.php
/inc/lib/redux-framework/config.php
/inc/functions/taxonomy-meta.php
/inc/functions/template-functions.php
/css/responsive.css

#### change log - 1.0.5 #####
/inc/admin/tour/orders-admin-panel.php

#### change log - 1.0.4 #####
single-tour.php
/inc/functions/currency.php
/inc/functions/functions.php
/inc/functions/template-functions.php
/inc/lib/redux-framework/config.php
/inc/shortcode/shortcodes.php
/templates/hotel/checkout.php
/templates/hotel/loop-grid.php
/templates/hotel/loop-list.php
/templates/tour/checkout.php
/templates/tour/loop-grid.php
/templates/tour/loop-list.php