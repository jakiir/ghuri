<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

require_once( CT_INC_DIR . '/admin/tour/bookings-admin-panel.php' );
require_once( CT_INC_DIR . '/admin/tour/orders-admin-panel.php' );